<h1>Hello</>
Gw mau bagi source code evoting nih

<h1>Program ini dibuat dengan</h1>
<ul>
    <li>Html</li>
    <li>Bootstrap 4</li>
    <li>Javascript ( Jquery )</li>
    <li>SweetAlert 2</li>
    <li>Laravel 6</li>
</ul>

untuk database sudah ada di dalam folder Export Database ya.

<h1>Jangan lupa follow</h1>
<a href="https://www.instagram.com/dzakimuzh/">My instagram</a>
