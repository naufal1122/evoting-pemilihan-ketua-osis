<?php $__env->startSection('title'); ?>
    Tambah Paslon
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/Tambah.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="bg-primary mt-n4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="judul">
                    <h1 class="text-white mt-5">Upload Paslon</h1>
                </div>
                <div class="card mt-4 mb-5">
                    <div class="card-body">
                        <form action="/proses_tambah" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row mt-3 rowInput">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="exampleFormControlInput1">No Urut</label>
                                        <input type="text" class="form-control" id="exampleFormControlInput1"
                                            placeholder="Masukkan No Urut Paslon" name="no_urut_paslon"
                                            value="<?php echo e(old('no_urut_paslon')); ?>" required>

                                        <?php if( $errors->has('no_urut_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('no_urut_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="exampleFormControlInput1">Nama Ketua</label>
                                        <input type="text" class="form-control" id="exampleFormControlInput1"
                                            placeholder="Masukkan Nama Ketua" name="ketua_paslon"
                                            value="<?php echo e(old('ketua_paslon')); ?>" required>

                                        <?php if( $errors->has('ketua_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('ketua_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <!-- <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="exampleFormControlInput1">Nama Wakil</label>
                                        <input type="text" class="form-control" id="exampleFormControlInput1"
                                            placeholder="Masukkan Nama Wakil" name="wakil_paslon"
                                            value="<?php echo e(old('wakil_paslon')); ?>" required>

                                        <?php if( $errors->has('wakil_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('wakil_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div> -->
                            </div>
                            <div class="row mt-3 rowInput">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Visi</label>
                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                            name="visi_paslon" required><?php echo e(old('visi_paslon')); ?></textarea>

                                        <?php if( $errors->has('visi_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('visi_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Misi</label>
                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                            name="misi_paslon" required><?php echo e(old('misi_paslon')); ?></textarea>

                                        <?php if( $errors->has('misi_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('misi_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3 rowInput">
                                <div class="col-md-6">
                                    <label for="gambarKetua">Gambar Ketua</label>
                                    <div class="input-group mb-3">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="gambarKetua"
                                                aria-describedby="inputGroupFileAddon01" name="img_ketua"
                                                value="<?php echo e(old('img_ketua')); ?>" onchange="previewImage()" required>
                                            <label class="custom-file-label d-flex" id="label" for="gambarKetua">
                                                <p id="filenameKetua">Choose file</p>
                                            </label>
                                        </div>
                                    </div>
                                    <?php if( $errors->has('img_ketua') ): ?>
                                    <div class="text-danger mt-n2">
                                        <?php echo e($errors->first('img_ketua')); ?>

                                    </div>
                                    <?php endif; ?>
                                </div>
                                <!-- <div class="col-md-6">
                                    <label for="gambarWakil">Gambar Wakil</label>
                                    <div class="input-group mb-3">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="gambarWakil"
                                                aria-describedby="inputGroupFileAddon01" name="img_wakil"
                                                value="<?php echo e(old('img_wakil')); ?>" onchange="previewImage()" required>
                                            <label class="custom-file-label" for="gambarWakil">
                                                <p id="filenameWakil">Choose file</p>
                                            </label>
                                        </div>
                                    </div>
                                    <?php if( $errors->has('img_wakil') ): ?>
                                    <div class="text-danger mt-n2">
                                        <?php echo e($errors->first('img_wakil')); ?>

                                    </div>
                                    <?php endif; ?>
                                </div> -->
                            </div>
                            <div class="row mt-4 mb-3 rowInput">
                                <div class="col-md-12">
                                    <a href="/dashboard" class="btn btn-danger">Kembali</a>
                                    <button type="submit" class="btn btn-primary m-auto">Upload Paslon</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="/js/preview.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\evoting-pemilihan-ketua-osis\resources\views/admin/tambah.blade.php ENDPATH**/ ?>