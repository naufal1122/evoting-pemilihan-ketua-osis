<table class="table table-bordered mx-auto mt-3 table-striped table-responsive" style="width: 100%;">
    <thead>
        <tr>
            <th class="text-center" width="2%">No</th>
            <th class="text-center" width="4%">Username</th>
            <th class="text-center" width="9%">Nama Panjang</th>
            <th class="text-center" width="2%">NIS</th>
            <th class="text-center" width="2%">Kelas</th>
            <th class="text-center" width="9%">Status Voting</th>
            <th class="text-center" width="7%">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="7" class="text-center">Tidak Ada Siswa</td>
        </tr>
        <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e(($data->currentPage() - 1) * $data->perPage() + $loop->iteration); ?></td>
            <td class="text-center"><?php echo e($siswa->username); ?></td>
            <td class="text-center"><?php echo e($siswa->nama_panjang); ?></td>
            <td class="text-center"><?php echo e($siswa->password); ?></td>
            <td class="text-center"><?php echo e($siswa->kelas); ?></td>
            <td class="text-center">
                    <?php if($siswa->voting): ?>
                        Sudah Memilih
                    <?php else: ?>
                        Belum Memilih
                    <?php endif; ?>
                </td>
            <td class="text-center">
                <a href="#" class="btn btn-primary btnaksi">Detail</a>
                <form id="deleteForm-<?php echo e($siswa->id); ?>" action="<?php echo e(route('siswa.hapus', $siswa->id)); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
                <button type="button" class="btn btn-danger" onclick="confirmDelete(<?php echo e($siswa->id); ?>)">Hapus</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>

<!-- Render pagination links -->
<div class="d-flex justify-content-center mt-3">
    <?php echo e($data->links()); ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function confirmDelete(id) {
    Swal.fire({
        title: 'Yakin ingin menghapus?',
        text: 'Data siswa akan dihapus dan tidak dapat dikembalikan!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            // Jika diklik "Ya, hapus!", kirimkan form
            document.getElementById('deleteForm-' + id).submit();
        } else if (result.isDismissed) {
            Swal.fire('Penghapusan dibatalkan!', '', 'info');
        }
    });
}
</script>
<?php /**PATH C:\laragon\www\evoting-pemilihan-ketua-osis\resources\views/admin/partials/_listSiswaTable.blade.php ENDPATH**/ ?>