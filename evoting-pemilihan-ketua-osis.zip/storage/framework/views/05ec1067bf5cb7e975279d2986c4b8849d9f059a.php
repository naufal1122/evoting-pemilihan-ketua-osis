<?php $__env->startSection('title'); ?>
Import Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/importSiswa.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="bg-primary mt-n4">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-2">
                <div class="judul">
                    <h1 class="text-white mt-5">Import Siswa</h1>
                </div>
                <div class="card mt-4 mb-5 mx-auto">
                    <div class="card-body">
                        <form action="/user/import_excel" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row mt-3 rowInput">
                                <div class="col-md-12">
                                    <div class="input-group mb-3">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="fileExcel"
                                                aria-describedby="inputGroupFileAddon01" name="file_excel"
                                                onchange="document.getElementById('filenameExcel').innerText = this.value.split('\\').pop();" required>
                                            <label class="custom-file-label" for="fileExcel">
                                                <p id="filenameExcel">Choose file</p>
                                            </label>
                                        </div>
                                    </div>
                                    <?php if($errors->has('file_excel')): ?>
                                    <div class="text-danger mt-n2">
                                        <?php echo e($errors->first('file_excel')); ?>

                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mt-4 mb-3 rowInput">
                                <div class="col-md-12">
                                    <a href="/dashboard" class="btn btn-danger">Kembali</a>
                                    <button type="submit" class="btn btn-primary m-auto">Import Siswa</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="/js/preview.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\evoting-pemilihan-ketua-osis\resources\views/admin/importSiswa.blade.php ENDPATH**/ ?>