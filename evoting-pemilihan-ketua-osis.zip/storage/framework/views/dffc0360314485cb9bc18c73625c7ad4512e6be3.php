<?php $__env->startSection('title'); ?>
Edit Paslon
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/edit.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="bg-primary mt-n4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="judul">
                    <h1 class="text-white mt-5">Edit Paslon</h1>
                </div>
                <div class="card mb-5 mt-4">
                    <div class="card-body">
                        <form action="/proses_edit/<?php echo e($data->id); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('PUT')); ?>

                            <div class="row mt-3 rowInput">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="exampleFormControlInput1">No Urut</label>
                                        <input type="text" class="form-control" id="exampleFormControlInput1"
                                            placeholder="Masukkan No Urut Paslon" name="no_urut_paslon"
                                            value="<?php echo e(( $errors->all() ) ? old('no_urut_paslon') : $data->no_urut_paslon); ?>">

                                        <?php if( $errors->has('no_urut_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('no_urut_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-md-10">
                                    <div class="form-group">
                                        <label for="exampleFormControlInput1">Nama Ketua</label>
                                        <input type="text" class="form-control" id="exampleFormControlInput1"
                                            placeholder="Masukkan Nama Ketua" name="ketua_paslon"
                                            value="<?php echo e(( $errors->all() ) ? old('ketua_paslon') : $data->ketua_paslon); ?>">

                                        <?php if( $errors->has('ketua_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('ketua_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <!-- <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="exampleFormControlInput1">Nama Wakil</label>
                                        <input type="text" class="form-control" id="exampleFormControlInput1"
                                            placeholder="Masukkan Nama Wakil" name="wakil_paslon"
                                            value="<?php echo e(( $errors->all() ) ? old('wakil_paslon') : $data->wakil_paslon); ?>">

                                        <?php if( $errors->has('wakil_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('wakil_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div> -->
                            </div>
                            <div class="row mt-3 rowInput">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Visi</label>
                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                            name="visi_paslon"><?php echo e(( $errors->all() ) ? old('visi_paslon') : $data->visi_paslon); ?></textarea>

                                        <?php if( $errors->has('visi_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('visi_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Misi</label>
                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                            name="misi_paslon"><?php echo e(( $errors->all() ) ? old('misi_paslon') : $data->misi_paslon); ?></textarea>

                                        <?php if( $errors->has('misi_paslon') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('misi_paslon')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3 rowInput">
                                <div class="col-md-12">
                                    <label for="img_ketua">Gambar Ketua</label>
                                    <div class="input-group mb-3">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="gambarKetua"
                                                aria-describedby="inputGroupFileAddon01" name="img_ketua" onchange="previewImage()">
                                            <label class="custom-file-label" for="gambarKetua">
                                                <p id="filenameKetua"><?php echo e($data->img_ketua); ?></p>
                                            </label>
                                        </div>
                                        <?php if( $errors->has('img_ketua') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('img_ketua')); ?>

                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <!-- Tambahkan Preview Gambar -->
                                    <img id="previewKetua" src="<?php echo e(asset('img_ketua/' . $data->img_ketua)); ?>" alt="Preview Gambar Ketua" style="max-width: 15%; height: auto; margin-top: 10px;">
                                </div>
                            </div>
                                <!-- <div class="col-md-6">
                                    <label for="gambarWakil">Gambar Wakil</label>
                                    <div class="input-group mb-3">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="gambarWakil"
                                                aria-describedby="inputGroupFileAddon01" name="img_wakil"
                                                value="<?php echo e(( $errors->all() ) ? old('img_wakil') : $data->img_wakil); ?>"
                                                onchange="previewImage()">
                                            <label class="custom-file-label" for="gambarWakil">
                                                <p id="filenameWakil"><?php echo e($data->img_wakil); ?></p>
                                            </label>

                                            <?php if( $errors->has('img_wakil') ): ?>
                                            <div class="text-danger">
                                                <?php echo e($errors->first('img_wakil')); ?>

                                            </div>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div> -->
                            </div>
                            <div class="row mt-4 mb-3 rowInput">
                                <div class="col-md-12">
                                    <a href="/dashboard" class="btn btn-danger">Kembali</a>
                                    <button type="submit" class="btn btn-primary m-auto">Edit Paslon</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="/js/preview.js"></script>
    <script>
    function previewImage() {
    const imgKetua = document.getElementById('gambarKetua');
    const filenameKetua = document.getElementById('filenameKetua');
    const previewKetua = document.getElementById('previewKetua');

    // Cek jika ada file yang diunggah
    if (imgKetua.files && imgKetua.files[0]) {
        const reader = new FileReader();

        reader.onload = function(e) {
            // Tampilkan preview gambar
            previewKetua.src = e.target.result;
            filenameKetua.textContent = imgKetua.files[0].name; // Tampilkan nama file
        }

        reader.readAsDataURL(imgKetua.files[0]);
    } else {
        // Reset preview jika tidak ada file
        previewKetua.src = '';
        filenameKetua.textContent = '';
    }
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\evoting-pemilihan-ketua-osis\resources\views/admin/edit.blade.php ENDPATH**/ ?>