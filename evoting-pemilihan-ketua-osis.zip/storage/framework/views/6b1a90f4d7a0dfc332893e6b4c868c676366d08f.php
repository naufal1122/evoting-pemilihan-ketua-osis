<?php $__env->startSection('title'); ?>
Kandidat
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/dashboard.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="bg-primary mt-n4">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-12 mt-5">
                <div class="header">
                    <h1 class="text-white">Kandidat</h1>
                </div>
                <div class="card mt-3">
                    <div class="card-body mx-auto" style="width: 95%">
                        <div class="col-md-12 p-0">
                            <a href="/dashboard" class="btn btn-outline-secondary mt-2 btnpaslon">Dashboard</a>
                                <div class="dropdown float-right">
                                        <a href="/tambah" class="btn btn-success mt-2 btnpaslon">Tambah Calon</a>
                                </div>
                                <table class="table table-bordered mx-auto mt-3 table-striped table-responsive">
                                <thead>
                                    <tr>
                                        <th class="text-center" width="9%">No Urut</th>
                                        <th class="text-center" width="23%">Nama Ketua</th>
                                        <!-- <th class="text-center" width="23%">Nama Wakil</th> -->
                                        <th class="text-center" width="25%">Aksi</th>
                                    </tr>
                                </thead>
                                <?php if( count($data) == 0 ): ?>
                                <tbody>
                                    <tr>
                                        <td colspan="6" align="center">Tidak Ada Caketos</td>
                                    </tr>
                                </tbody>
                                <?php else: ?>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($d->no_urut_paslon); ?></td>
                                        <td class="text-center"><?php echo e($d->ketua_paslon); ?></td>
                                        <!-- <td class="text-center"><?php echo e($d->wakil_paslon); ?></td> -->
                                        <td class="text-center">
                                            <a href="/edit/<?php echo e($d->id); ?>" class="btn btn-primary btnaksi">Edit</a>
                                            <a href="/detailPaslon/<?php echo e($d->id); ?>"
                                                class="btn btn-success btnDetail btnaksi">Detail</a>
                                            <a href="javascript:void(0);" class="btn btn-danger btnaksi" onclick="confirmDelete(<?php echo e($d->id); ?>)">Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>\
<script>
function confirmDelete(id) {
    Swal.fire({
        title: 'Yakin ingin dihapus?',
        text: 'Data ini akan dihapus dan tidak dapat dikembalikan!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            // Jika "Ya, hapus!" diklik, arahkan ke URL hapus
            window.location.href = '/hapus/' + id;
        }
    });
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\evoting-pemilihan-ketua-osis\resources\views/admin/kandidat.blade.php ENDPATH**/ ?>