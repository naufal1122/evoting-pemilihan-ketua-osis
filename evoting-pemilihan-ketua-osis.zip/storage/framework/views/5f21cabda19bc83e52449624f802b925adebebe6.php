<?php $__env->startSection('title'); ?>
Hasil Vote
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/hasilVote.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="bg-primary mt-n4">
    <div class="container">
        <div class="row judul mx-auto">
            <div class="col-md-5 mt-5">
                <h1 class="text-white">Hasil Vote</h1>
            </div>
        </div>
        <div class="row mx-auto rowCard d-flex justify-content-center mt-4">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4"> <!-- Ubah col-md-5 menjadi col-md-4 -->
                <div class="card shadow-lg border-light">
                    <div class="card-header bg-light text-center">
                        <h5 class="text-dark font-weight-bold">Paslon No <?php echo e($d['no_urut_paslon']); ?></h5>
                    </div>
                    <div class="card-body d-flex justify-content-center align-items-center">
                        <h1 class="hasil text-success font-weight-bold display-2"><?php echo e($d['jumlah_vote']); ?></h1>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-md-12 mt-2">
            <div class="card mt-2">
                <div class="card-body d-flex flex-column" style="width: 100%;">
                    <div class="row mt-4 flex-grow-1">
                        <div class="col-md-12">
                            <canvas id="votingChart" style="width: 100%; height: 100%;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(( Auth::user()->role == 'admin' ) ? '/dashboard' : '/home'); ?>"
                   class="btn btn-danger mx-auto d-block mt-4 btnKembali rounded-pill">Kembali</a>
            </div>
        </div>
    </div>

</section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    $(document).ready(function() {
        function updateVoteResults() {
            $.get('/user/hasil_vote_ajax', function(data) {
                data.forEach(function(item) {
                    $('#vote-result-' + item.no_urut_paslon).text(item.jumlah_vote);
                });
            });
        }

        // Update hasil setiap 5 detik
        setInterval(updateVoteResults, 5000);
    });

    // Ambil data dari PHP
    const data = <?php echo json_encode($data, 15, 512) ?>;

    // Siapkan data untuk chart
    const labels = data.map(d => `Paslon No ${d.no_urut_paslon}`);
    const votes = data.map(d => d.jumlah_vote);

    // Membuat chart
    const ctx = document.getElementById('votingChart').getContext('2d');
    const votingChart = new Chart(ctx, {
        type: 'bar', // Tipe chart (bisa diganti dengan 'pie', 'line', dll)
        data: {
            labels: labels,
            datasets: [{
                label: 'Jumlah Suara',
                data: votes,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Jumlah Suara'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Paslon'
                    }
                }
            }
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\evoting-pemilihan-ketua-osis\resources\views/admin/hasilVote.blade.php ENDPATH**/ ?>