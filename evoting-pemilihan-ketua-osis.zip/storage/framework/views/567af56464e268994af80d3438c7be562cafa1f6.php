<?php $__env->startSection('title'); ?>
Register Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/registerSiswa.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="bg-primary mt-n4">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-2">
                <div class="judul">
                    <h1 class="text-white mt-5">Register Siswa</h1>
                </div>
                <div class="card mt-4 mb-5">
                    <div class="card-body">
                        <form action="/prosesRegisterSiswa" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row mt-3 rowInput">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input type="text" class="form-control" id="username"
                                            placeholder="Masukkan Username Siswa" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>

                                        <?php if( $errors->has('username') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('username')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="text">Nama Lengkap</label>
                                        <input type="text" class="form-control" id="nama_panjang"
                                            placeholder="Masukkan Nama Lengkap Siswa" name="nama_panjang" value="<?php echo e(old('nama_panjang')); ?>" required autocomplete="nama_panjang">

                                        <?php if( $errors->has('nama_panjang') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('nama_panjang')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="text">Kelas</label>
                                        <input type="text" class="form-control" id="kelas"
                                            placeholder="Masukkan Kelas Siswa" name="kelas" value="<?php echo e(old('kelas')); ?>" required autocomplete="kelas">

                                        <?php if( $errors->has('kelas') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('kelas')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="password">NIS</label>
                                        <input type="text" class="form-control" id="password"
                                            placeholder="Masukkan NIS" name="password" value="<?php echo e(old('password')); ?>" required autocomplete="password">

                                        <?php if( $errors->has('password') ): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('password')); ?>

                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <div class="row mt-4 mb-3 rowInput">
                                <div class="col-md-12">
                                    <a href="/dashboard" class="btn btn-danger">Kembali</a>
                                    <button type="submit" class="btn btn-primary m-auto">Register Siswa</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\evoting-pemilihan-ketua-osis\resources\views/admin/registerSiswa.blade.php ENDPATH**/ ?>