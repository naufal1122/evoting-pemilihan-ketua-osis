<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use App\User; // Tambahkan ini untuk model User

class LoginController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectTo = RouteServiceProvider::HOME;

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    protected function logout(Request $request)
    {
        Auth::logout();
        return redirect('/'); // Atau redirect ke halaman lain
    }

    public function login(Request $request) {
        $this->validate($request, [
            'username' => 'required',
            'password' => 'required'
        ]);

        // Mencari user berdasarkan username
        $user = User::where('username', $request->username)->first();

        // Cek apakah user ada dan passwordnya sama
        if ($user && $user->password === $request->password) {
            Auth::login($user);
            Alert::success('Success', 'Login Berhasil');
            return redirect()->route('home');
        } else {
            Alert::warning('Warning', 'Username/Password Salah');
            return redirect()->route('login');
        }
    }
}
